package z_homework.basket3X3;

public class SpecialPlayer extends Player {

	
	public SpecialPlayer(String name, String position, double height, int rebound, int threePoint, int twoPoint,
			int block, int running) {
		super(name, position, height, rebound, threePoint, twoPoint, block, running);
	
	}

	
}
